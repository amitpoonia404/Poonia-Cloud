import commands
import socket,os,string
s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
port=1234
s.bind(("",port))


user =s.recvfrom(100)
print user

password =s.recvfrom(10)
print password
#while True:
if user == "root" and password == "bughunter":
	while True:
		print "not"
else: 
		print "ok"
	
c=commands.getstatusoutput("systemctl disable firewalld")
if c[0] == 0:
		print "Received"	
		s.sendto("ok",(user[1][0], 8989))
else:
		s.sendto("not", (user[1][0], 8989))




